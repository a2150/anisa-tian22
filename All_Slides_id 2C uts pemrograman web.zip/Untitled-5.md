**/*.min.js
**/plugins/
/.temp/
/dist/
/docs/
/docs_html/
**/env.d.ts